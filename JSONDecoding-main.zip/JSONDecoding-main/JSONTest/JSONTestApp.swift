//
//  JSONTestApp.swift
//  JSONTest
//
//  Created by Federico on 08/02/2022.
//

import SwiftUI

@main
struct JSONTestApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
